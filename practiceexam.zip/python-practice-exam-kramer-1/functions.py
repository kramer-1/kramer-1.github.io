"""
1.  Write a program that lists the numbers
    from 0-10 on separate lines
"""

for i in range(11):
    print(i)

"""
2.  Write a program that counts down from
   100 by 5's
"""

n=105
for i in range(21):
    n=n-5
    print(n)

"""
3.  Write a function called Triple(x):
This Function should take the value x and
Return 3 times that number. Call the function
and print the result to the screen for x = 20
"""

def Triple(x):
    print(3*x)

Triple(20)

"""
4.  Write a program that will ask the user
to input a number, triple it and  display
the result.  You will NEED print statements
AND you may use your function above.
"""

x=input('Enter a number: ')
Triple(int(x))
