"""
1. Write the lines of code that would import
and create a turtle named 'Pong'.
"""

import turtle
Pong=turtle.Turtle()
Pong.speed(0)

"""
2.  Draw a square with Pong of length 100
"""

for i in range(4):
    Pong.forward(100)
    Pong.right(90)

"""
3.  Write a function that will allow the user
to input the length of a square and then draw
a square of that length.
"""

length=input('Enter a length for your square: ')
for i in range(4):
    Pong.forward(int(length))
    Pong.left(90)

"""
4.  Draw a series of squares with different sizes
that share the same corner.
"""
z=-25
for i in range(20):
    z=z+25
    for n in range(4):
        Pong.forward(25+z)
        Pong.right(90)

"""
5.  Repeat the question above but change the color
each time it draws a square.
"""
import random
colors  = ["red","green","blue","orange","purple","pink","yellow"]

g=-25
for h in range(20):
    color = random.choice(colors)
    g=g+25
    for j in range(4):
        Pong.forward(25+g)
        Pong.right(90)





        
